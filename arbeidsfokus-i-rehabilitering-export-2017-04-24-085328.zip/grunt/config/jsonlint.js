module.exports = {
  src: [ '<%= sourcedir %>course/**/*.json' ]
}
