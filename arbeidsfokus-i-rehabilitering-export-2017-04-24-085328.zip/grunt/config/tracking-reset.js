module.exports = {
    options: {
        courseFile: '<%= sourcedir %>course/en/course.json',
        blocksFile: '<%= sourcedir %>course/en/blocks.json'
    }
}
