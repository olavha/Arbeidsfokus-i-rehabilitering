module.exports = {
    server: ['connect:server', 'open:server'],
    spoor: ['connect:spoorOffline', 'open:spoor']
}
